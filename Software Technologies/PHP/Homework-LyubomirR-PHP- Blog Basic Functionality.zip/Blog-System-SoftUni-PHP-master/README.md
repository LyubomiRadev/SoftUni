# Blog-System-SoftUni-PHP
Blog System using PHP + MySQL + Apache + HTML + CSS
